package com.example.desafiorm240112

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var editTextMonto: EditText
    private lateinit var editTextPersonas: EditText
    private lateinit var radio10: RadioButton
    private lateinit var radio15: RadioButton
    private lateinit var radio20: RadioButton
    private lateinit var radioOtro: RadioButton
    private lateinit var radioGroup: RadioGroup
    private lateinit var switchIva: Switch
    private lateinit var btnCalcular: Button
    private lateinit var btnLimpiar: Button
    private lateinit var tvResultado: TextView
    private lateinit var editTextOtroPorcentaje: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Enlazamos los componentes visuales con las variables
        editTextMonto = findViewById(R.id.editTextMonto)
        editTextPersonas = findViewById(R.id.editTextPersonas)
        radio10 = findViewById(R.id.radio10)
        radio15 = findViewById(R.id.radio15)
        radio20 = findViewById(R.id.radio20)
        radioOtro = findViewById(R.id.radioOtro)
        radioGroup = findViewById(R.id.radioGroup)
        switchIva = findViewById(R.id.switchIva)
        btnCalcular = findViewById(R.id.btnCalcular)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        tvResultado = findViewById(R.id.tvResultado)
        editTextOtroPorcentaje = findViewById(R.id.editTextOtroPorcentaje)

        // Acciones de los botones
        btnCalcular.setOnClickListener {
            calcularPropina()
        }

        btnLimpiar.setOnClickListener {
            limpiarCampos()
        }

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.radioOtro) {
                editTextOtroPorcentaje.visibility = View.VISIBLE
            } else {
                editTextOtroPorcentaje.visibility = View.GONE
                editTextOtroPorcentaje.text.clear()
            }
        }
    }

    private fun calcularPropina() {
        val montoStr = editTextMonto.text.toString()
        val personasStr = editTextPersonas.text.toString()

        if (montoStr.isEmpty() || personasStr.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val monto = montoStr.toDouble()
        val personas = personasStr.toInt()
        if (personas <= 0) {
            Toast.makeText(this, "Número de personas debe ser mayor a cero", Toast.LENGTH_SHORT).show()
            return
        }

        // Determinar el porcentaje de propina
        val porcentaje = when (radioGroup.checkedRadioButtonId) {
            R.id.radio10 -> 0.10
            R.id.radio15 -> 0.15
            R.id.radio20 -> 0.20
            R.id.radioOtro -> {
                val otroStr = editTextOtroPorcentaje.text.toString()
                if (otroStr.isEmpty()) {
                    Toast.makeText(this, "Ingresa el porcentaje personalizado", Toast.LENGTH_SHORT).show()
                    return
                }
                val otroPorcentaje = otroStr.toDoubleOrNull()
                if (otroPorcentaje == null || otroPorcentaje <= 0) {
                    Toast.makeText(this, "Porcentaje inválido", Toast.LENGTH_SHORT).show()
                    return
                }
                otroPorcentaje / 100.0
            }
            else -> {
                Toast.makeText(this, "Selecciona un porcentaje de propina", Toast.LENGTH_SHORT).show()
                return
            }
        }

        var total = monto
        if (switchIva.isChecked) {
            total *= 1.16
        }

        val propina = total * porcentaje
        val totalFinal = total + propina
        val porPersona = totalFinal / personas

        val resultado = """
            Total con propina: $${"%.2f".format(totalFinal)}
            Cada persona paga: $${"%.2f".format(porPersona)}
        """.trimIndent()

        tvResultado.text = resultado
    }

    private fun limpiarCampos() {
        editTextMonto.text.clear()
        editTextPersonas.text.clear()
        radioGroup.clearCheck()
        switchIva.isChecked = false
        tvResultado.text = ""
    }
}